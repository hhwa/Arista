package footer;


import com.opensymphony.xwork2.ActionSupport;

public class footerAction extends ActionSupport{
	
	public String layout() throws Exception{
		return SUCCESS;
	}
}

