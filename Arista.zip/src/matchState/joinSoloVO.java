package matchState;

public class joinSoloVO {
	private int match_no;		//매치번호
	private int game_no;		//경기번호
	private String mem_id;
	private int mem_idCount;	//참가인원
	private int isJoinSoloMatch;
	public int getMatch_no() {
		return match_no;
	}
	public void setMatch_no(int match_no) {
		this.match_no = match_no;
	}
	public int getGame_no() {
		return game_no;
	}
	public void setGame_no(int game_no) {
		this.game_no = game_no;
	}
	public int getIsJoinSoloMatch() {
		return isJoinSoloMatch;
	}
	public void setIsJoinSoloMatch(int isJoinSoloMatch) {
		this.isJoinSoloMatch = isJoinSoloMatch;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getMem_idCount() {
		return mem_idCount;
	}
	public void setMem_idCount(int mem_idCount) {
		this.mem_idCount = mem_idCount;
	}
	public int getisJoinSoloMatch() {
		return isJoinSoloMatch;
	}
	public void setisJoinSoloMatch(int isJoinSoloMatch) {
		this.isJoinSoloMatch = isJoinSoloMatch;
	}
	
	
}
