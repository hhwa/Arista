package stadium;

import java.util.Date;

public class stadiumVO {
            private int stadium_no;
            private String stadium_name;
            private String stadium_tel;
            private int stadium_zipcode;
            private String stadium_addr;
            private String stadium_day; 
            private String stadium_time;
            private String stadium_main_img_org;
            private String stadium_main_img_save;
            private Date stadium_regdate;
			
            
            public int getStadium_no() {
				return stadium_no;
			}
			public void setStadium_no(int stadium_no) {
				this.stadium_no = stadium_no;
			}
			public String getStadium_name() {
				return stadium_name;
			}
			public void setStadium_name(String stadium_name) {
				this.stadium_name = stadium_name;
			}
			public String getStadium_tel() {
				return stadium_tel;
			}
			public void setStadium_tel(String stadium_tel) {
				this.stadium_tel = stadium_tel;
			}
			public int getStadium_zipcode() {
				return stadium_zipcode;
			}
			public void setStadium_zipcode(int stadium_zipcode) {
				this.stadium_zipcode = stadium_zipcode;
			}
			public String getStadium_addr() {
				return stadium_addr;
			}
			public void setStadium_addr(String stadium_addr) {
				this.stadium_addr = stadium_addr;
			}
			public String getStadium_day() {
				return stadium_day;
			}
			public void setStadium_day(String stadium_day) {
				this.stadium_day = stadium_day;
			}
			public String getStadium_time() {
				return stadium_time;
			}
			public void setStadium_time(String stadium_time) {
				this.stadium_time = stadium_time;
			}
			public String getStadium_main_img_org() {
				return stadium_main_img_org;
			}
			public void setStadium_main_img_org(String stadium_main_img_org) {
				this.stadium_main_img_org = stadium_main_img_org;
			}
			public String getStadium_main_img_save() {
				return stadium_main_img_save;
			}
			public void setStadium_main_img_save(String stadium_main_img_save) {
				this.stadium_main_img_save = stadium_main_img_save;
			}
			public Date getStadium_regdate() {
				return stadium_regdate;
			}
			public void setStadium_regdate(Date stadium_regdate) {
				this.stadium_regdate = stadium_regdate;
			}
			
           
            
           
              
}
